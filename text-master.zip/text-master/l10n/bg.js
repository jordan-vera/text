OC.L10N.register(
    "text",
    {
    "Text" : "Текст",
    "Retry" : "Опитай отново",
    "Edit" : "Променяне",
    "Undo" : "Отмяна",
    "Bold" : "Удебелен",
    "Italic" : "Курсив"
},
"nplurals=2; plural=(n != 1);");
