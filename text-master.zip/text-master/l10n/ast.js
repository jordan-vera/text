OC.L10N.register(
    "text",
    {
    "Text" : "Testu",
    "Retry" : "Retentar",
    "Edit" : "Editar",
    "Undo" : "Desfacer"
},
"nplurals=2; plural=(n != 1);");
