OC.L10N.register(
    "text",
    {
    "Text" : "متن",
    "Retry" : "تلاش دوباره",
    "Edit guest name" : "ویرایش نام مهمان",
    "Save guest name" : "ذخیره نام مهمان",
    "Add link" : "افزودن لینک",
    "Show image" : "نمایش تصویر",
    "Show file" : "نمایش فایل",
    "Edit" : "ویرایش",
    "Undo" : "برگرداندن",
    "Bold" : "درشت",
    "Italic" : "Italic"
},
"nplurals=2; plural=(n > 1);");
