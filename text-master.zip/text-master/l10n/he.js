OC.L10N.register(
    "text",
    {
    "Text" : "טקסט",
    "Retry" : "ניסיון חוזר",
    "Unsaved changes" : "שינויים שלא נשמרו",
    "Edit" : "עריכה",
    "Undo" : "ביטול",
    "Bold" : "מודגש",
    "Italic" : "נטוי"
},
"nplurals=4; plural=(n == 1 && n % 1 == 0) ? 0 : (n == 2 && n % 1 == 0) ? 1: (n % 10 == 0 && n % 1 == 0 && n > 10) ? 2 : 3;");
