OC.L10N.register(
    "text",
    {
    "Text" : "Tekst",
    "Retry" : "Prøv igjen",
    "Unsaved changes" : "Ulagrede endringer",
    "Edit" : "Rediger",
    "Undo" : "Angre",
    "Redo" : "Gjør om",
    "Bold" : "Uthevet",
    "Italic" : "Italic",
    "Strikethrough" : "Gjennomstreking"
},
"nplurals=2; plural=(n != 1);");
