OC.L10N.register(
    "text",
    {
    "Retry" : "Дахин оролдох",
    "Edit" : "засварлах",
    "Undo" : "буцах"
},
"nplurals=2; plural=(n != 1);");
