OC.L10N.register(
    "text",
    {
    "Text" : "Teksts",
    "Retry" : "Mēģināt vēlreiz",
    "Edit" : "Rediģēt",
    "Undo" : "Atsaukt",
    "Redo" : "Atcelt atsaukšanu",
    "Bold" : "Treknraksts",
    "Italic" : "Slīpraksts",
    "Strikethrough" : "Pārsvītrojums"
},
"nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n != 0 ? 1 : 2);");
