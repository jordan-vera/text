OC.L10N.register(
    "text",
    {
    "Text" : "ტექსტი",
    "Retry" : "ვცადოთ ახლიდან",
    "Unsaved changes" : "შეუნახავი ცვლილებები",
    "Edit" : "ცვლილება",
    "Undo" : "დაბრუნება"
},
"nplurals=2; plural=(n!=1);");
