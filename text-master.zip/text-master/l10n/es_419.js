OC.L10N.register(
    "text",
    {
    "Text" : "Texto",
    "Retry" : "Reintentar",
    "Unsaved changes" : "Cambios no guardados",
    "Edit" : "Editar",
    "Undo" : "Deshacer"
},
"nplurals=2; plural=(n != 1);");
