OC.L10N.register(
    "text",
    {
    "Text" : "Besedilo",
    "📝 Collaborative document editing" : "📝 Sodelovalno urejanje dokumentov",
    "Retry" : "Poskusi  znova",
    "Unsaved changes" : "Neshranjene spremembe",
    "Edit guest name" : "Uredi ime gosta",
    "Save guest name" : "Shrani ime gosta",
    "Show image" : "Pokaži sliko",
    "Edit" : "Uredi",
    "Undo" : "Razveljavi",
    "Redo" : "Ponovi",
    "Bold" : "Krepko",
    "Italic" : "Ležeče",
    "Strikethrough" : "Prečrtano",
    "New text document.md" : "Nova besedilna datoteka.md"
},
"nplurals=4; plural=(n%100==1 ? 0 : n%100==2 ? 1 : n%100==3 || n%100==4 ? 2 : 3);");
