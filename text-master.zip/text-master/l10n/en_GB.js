OC.L10N.register(
    "text",
    {
    "Text" : "Text",
    "Retry" : "Retry",
    "Unsaved changes" : "Unsaved changes",
    "Edit" : "Edit",
    "Undo" : "Undo",
    "Bold" : "Bold",
    "Italic" : "Italic"
},
"nplurals=2; plural=(n != 1);");
