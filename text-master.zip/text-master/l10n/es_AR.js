OC.L10N.register(
    "text",
    {
    "Text" : "Texto",
    "Retry" : "Reintentar",
    "Edit" : "Editar",
    "Undo" : "Deshacer",
    "Bold" : "Negrita",
    "Italic" : "Itálico"
},
"nplurals=2; plural=(n != 1);");
