OC.L10N.register(
    "text",
    {
    "Text" : "텍스트",
    "Retry" : "다시 시도",
    "Unsaved changes" : "저장하지 않은 변경 사항",
    "Edit" : "편집",
    "Undo" : "실행 취소"
},
"nplurals=1; plural=0;");
