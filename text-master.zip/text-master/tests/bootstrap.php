<?php

require_once __DIR__ . '/../../../tests/bootstrap.php';

\OC_App::loadApp('text');
OC_Hook::clear();
